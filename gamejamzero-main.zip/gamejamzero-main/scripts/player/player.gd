extends CharacterBody2D

@onready var movimentacao: Movimentacao = $movimentacao
@onready var interacao: Interacao = $interacao

@export var vel = 120
@export var aceleracao = 800
@export var desaceleracao = 800
var can_move: bool = true
func _ready() -> void:
	movimentacao._instanciar(vel, self, aceleracao, desaceleracao)

func _physics_process(delta: float) -> void:
	movimentacao._set_state(delta)
	
func travar_movimento(travado: bool):
	# Se 'travado' for true, o jogador não pode se mover. Se for false, ele pode.
	can_move = not travado
