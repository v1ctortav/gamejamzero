extends Node2D

@onready var dialogo_ui = $dialogo/PanelContainer
@onready var jogador = $player

func _ready():
	dialogo_ui.dialogo_encerrado.connect(_on_dialogo_encerrado)
	$caixa.evidencia_escaneada.connect(_on_vizinho_dialogo)

func iniciar_dialogo(id_do_vizinho: String):
	var dialogo_data = dialogos.get(id_do_vizinho)

	if dialogo_data != null:
		jogador.travar_movimento(true)
		dialogo_ui.start_dialogue(dialogo_data)

func _on_dialogo_encerrado():
	jogador.travar_movimento(false)

func _on_vizinho_dialogo(id_do_vizinho):
	iniciar_dialogo(id_do_vizinho)

var dialogos = {
	"vizinho_generico": {
		"texto": "teste 123",
		"opcoes": [
			{
				"texto": "testado",
				"resposta_vizinho": "testednv."
			}
		]
	}
}
